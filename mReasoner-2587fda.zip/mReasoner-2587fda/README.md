# mreasoner
mReasoner is a unified computational implementation of the model theory of thinking and reasoning
